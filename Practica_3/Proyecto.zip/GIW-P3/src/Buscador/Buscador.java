/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Buscador;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

/**
 *
 * @author Manuel
 */
public class Buscador {
    private String texto;
    private String directorio;
    private String ruta_stopwords;
    private ResultadosBusquedaGUI resGUI;
    
    public Buscador(){
        texto = " ";
        directorio = " ";
        ruta_stopwords = "palabras_vacias_utf8.txt";
        resGUI = new ResultadosBusquedaGUI();
    }
    
    public Buscador(String text, String directory, String stopwords){
        texto = text;
        directorio = directory;
        ruta_stopwords = stopwords;
        resGUI = new ResultadosBusquedaGUI();
    }
    
    /**
    * Función de lectura de las palabras vacías del 
    * documento text que se le pasa como ruta en string.
    * Devuelve la lista de palabras.
    */
    public static List<String> readStopWords(String ruta) throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        List<String> resultado;
        
        try {
            StringBuilder sb = new StringBuilder();
            String linea = br.readLine();

            while (linea != null) {
                sb.append(linea);
                sb.append(System.lineSeparator());
                linea = br.readLine();
            }
            String completo = sb.toString();
            resultado = Arrays.asList(completo);
        } finally {
            br.close();
        }
        
        return resultado;
    }
    
    public void Buscar() throws IOException, ParseException{
        ArrayList<Document> resultado = new ArrayList<Document>();
        CharArraySet stopwords;
        
        //Se lee el archivo de palabras vacías
        List<String> stopWords = readStopWords(ruta_stopwords);
        stopwords = new CharArraySet(stopWords, true);
        
        //Se crea el analizador
        Analyzer analyzer = new SpanishAnalyzer(stopwords);
        
        //Se crea el lector del directorio
        Path path = Paths.get(directorio);
        Directory index = FSDirectory.open(path);
        DirectoryReader ireader = DirectoryReader.open(index);
        
        //Se crea el buscador dentro del directorio establecido
        IndexSearcher isearcher = new IndexSearcher(ireader);
       
        //Se establece el campo de la consulta
        QueryParser parser = new QueryParser("texto", analyzer);
        Query query = parser.parse(texto);
        
        Document d = ireader.document(0);
        
        
        //Se realiza la búsqueda almacenando las coincidencias
        ScoreDoc[] hits  = isearcher.search(query, ireader.numDocs()).scoreDocs;
        
        for (int i = 0; i < hits.length; i++) {
            Document hitDoc = isearcher.doc(hits[i].doc);
            resultado.add(hitDoc);
        }

        ireader.close();
        index.close();
        
        //Se establece la lista de resultados
        resGUI.setResultados(resultado);
        resGUI.setBuscado(texto);
        resGUI.setVisible(true);
    }
}
