/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Indexador;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.lucene.document.Document;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.xml.sax.SAXException;
import org.apache.commons.io.*;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import static org.apache.lucene.index.DirectoryReader.indexExists;
import org.w3c.dom.NodeList;


/**
 *
 * @author Manuel
 */
public class Indexador {

    /**
    * Función de lectura de las palabras vacías del 
    * documento text que se le pasa como ruta en string.
    * Devuelve la lista de palabras.
    */
    public static List<String> readStopWords(String ruta) throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        List<String> resultado;
        
        try {
            StringBuilder sb = new StringBuilder();
            String linea = br.readLine();

            while (linea != null) {
                sb.append(linea);
                sb.append(System.lineSeparator());
                linea = br.readLine();
            }
            String completo = sb.toString();
            resultado = Arrays.asList(completo);
        } finally {
            br.close();
        }
        
        return resultado;
    }
    
    /*
    * Función de lectura de los documentos de noticias: Se obtiene la lista de archivos
    * dentro de la ruta que se le especifica. A cada uno le realiza una serie de operaciones
    * para arreglar el formato de cara a que sea posible exportarlo como objeto DOM.
    * Por último, teniendo cada documento como objeto DOM, obtengo los campos de Título y 
    * Texto de cada noticia, creando un objeto para cada una de ellas y almacenándolo en una lista,
    * que es la que se devuelve.
    */
    public static ArrayList<Noticia> readDocs(String ruta) throws ParserConfigurationException, SAXException, IOException{
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = factory.newDocumentBuilder();
        org.w3c.dom.Document documento;
        String doc_string = "";
        NodeList titulos;
        NodeList textos;
        
        ArrayList<Noticia> documentos = new ArrayList<Noticia>();
        
        File dir = new File(ruta);
        File[] directoryListing = dir.listFiles();
        if (directoryListing != null) {
            for(File doc : directoryListing){
                doc_string = FileUtils.readFileToString(new File(ruta+doc.getName()), "ISO-8859-1");
                
                //Se añade el delimitador raíz de tipo de documento
                doc_string = "<SGML>" + doc_string + "</SGML>";
                
                //Se modifican los caracteres con formato incorrecto
                doc_string = doc_string.replace("&", " ");
                doc_string = doc_string.replace("<\n<", "\n<");
                doc_string = doc_string.replace("< ", "  ");
                doc_string = doc_string.replace(";<", ";");
                
                
                documento = docBuilder.parse(new ByteArrayInputStream(new String(doc_string.getBytes("UTF-8"), "UTF-8").getBytes("UTF-8")),"UTF-8");
                documento.getDocumentElement().normalize();
                
                //Obtengo todos los títulos del documento
                titulos = documento.getElementsByTagName("TITLE");
                
                //Obtengo todos los textos del documento
                textos = documento.getElementsByTagName("TEXT");
                
                for(int i = 0; i<titulos.getLength(); i++){
                    documentos.add(new Noticia(titulos.item(i).getTextContent(),textos.item(i).getTextContent()));
                }
            }
        }
        
        return documentos;
    }
    
    public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException{
        String ruta_stopWords = args[0];
        String ruta_indice = args[1];
        String docsDirectory = args[2];
        
        Document docu = new Document();
        CharArraySet stopwords;
        
        System.out.println("Comienza el proceso de indexación...");
        
        //Se lee el archivo de palabras vacías
        List<String> stopWords = readStopWords(ruta_stopWords);
        stopwords = new CharArraySet(stopWords, true);
        
        //Se crea el analizador
        Analyzer analyzer = new SpanishAnalyzer(stopwords);
        
        //Se crea el directorio temporal donde se almacenará el índice
        Path path = Paths.get(ruta_indice);
        Directory directory = FSDirectory.open(path);
        
        //Se crea el objeto de configuración del escritor de índices
        IndexWriterConfig conf = new IndexWriterConfig(analyzer);
        
        //Se crea el escritor del índice
        IndexWriter iwriter = new IndexWriter(directory, conf);
        
        //Si ya existía el índice de una ejecución anterior, se elimina
        if (indexExists(FSDirectory.open(path))) {
            iwriter.deleteAll();
        }

        //Creación de documents
        ArrayList<Noticia> noticias = readDocs(docsDirectory);
        for(Noticia n: noticias){
            docu.clear();
            docu.add(new Field("titulo", n.getTitulo().replaceAll("(\\s)\\1","$1").replaceAll("\n", "").replaceAll(" +", " "), StringField.TYPE_STORED));
            docu.add(new Field("texto", n.getTexto(), TextField.TYPE_STORED));
            iwriter.addDocument(docu);
        }
        
        iwriter.close();
        
        System.out.println("¡Proceso de indexación completado!");
    }
}
