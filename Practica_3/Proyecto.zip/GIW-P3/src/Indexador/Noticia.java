
package Indexador;

/**
 *
 * @author Manuel
 * 
 * Clase de almacenamiento de noticias por: título y texto que continene.
 */
public class Noticia {
    private String titulo;
    private String texto;
    
    //Constructor por defecto de noticia
    public Noticia(){
        titulo = "";
        texto = "";
    }
    
    //Construtor con el título y el texto de una noticia
    public Noticia(String title, String text){
        titulo = title;
        texto = text;
    }
    
    //Getters-Setters///////////////////////
    public void setTitulo(String title){
        titulo = title;
    }
    
    public void setTexto(String text){
        texto = text;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getTexto(){
        return texto;
    }
    ////////////////////////////////////////
    
}
